<?
	include "../extras/php/conexion.php";
	include "../extras/php/basico.php";
	$sql = sprintf("delete from persona where ide_per=%d",
		(int)$_POST['ide_per']
	);
	if(!mysql_query($sql))
		echo "Ocurrio un error\n$sql";
	exit;
?>