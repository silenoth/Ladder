<?
	if(empty($_POST['ide_per'])){
		echo "Por favor no altere el fuente";
		exit;
	}

	include "../extras/php/basico.php";
	include "../extras/php/conexion.php";

	$sql = sprintf("select * from persona where ide_per=%d",
		(int)$_POST['ide_per']
	);
	$per = mysql_query($sql);
	$num_rs_per = mysql_num_rows($per);
	if ($num_rs_per==0){
		echo "No existen personas con ese IDE";
		exit;
	}
	
	$rs_per = mysql_fetch_assoc($per);
	
?>
<h1>Agregando nuevo usuario</h1>
<p>Por favor rellene el siguiente formulario</p>
<form action="javascript: fn_modificar();" method="post" id="frm_per">
	<input type="hidden" id="ide_per" name="ide_per" value="<?=$rs_per['ide_per']?>" />
    <table class="formulario">
        <tbody>
            <tr>
                <td>Usuario</td>
                <td><strong><?=$rs_per['usu_per']?></strong></td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td><input name="nom_per" type="text" id="nom_per" size="40" class="requisssred" value="<?=$rs_per['nom_per']?>" /></td>
            </tr>
            <tr>
                <td>Apellido</td>
                <td><input name="ape_per" type="text" id="ape_per" size="40" class="required" value="<?=$rs_per['ape_per']?>" /></td>
            </tr>
            <tr>
                <td>Pa&iacute;s</td>
                <td>
                	<select name="ide_pai" ide="ide_pai" class="required">
                    	<option value=""></option>
						<?
                            $sql = "select * from pais order by nom_pai asc";
                            $pai = mysql_query($sql);
                            while($rs_pai = mysql_fetch_assoc($pai)){
                        ?>
                            <option value="<?=$rs_pai['ide_pai']?>" <? if($rs_pai['ide_pai']==$rs_per['ide_pai']) echo "selected='selected'";?>><?=$rs_pai['nom_pai']?></option>
                        <? } ?>
					</select>
                </td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td><input name="email_per" type="text" id="email_per" size="30" class="required email" value="<?=$rs_per['email_per']?>" /></td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2">
                    <input name="modificar" type="submit" id="modificar" value="Modificar" />
                    <input name="cancelar" type="button" id="cancelar" value="Cancelar" onclick="fn_cerrar();" />
                </td>
            </tr>
        </tfoot>
    </table>
</form>
<script language="javascript" type="text/javascript">
	$(document).ready(function(){
		$("#frm_per").validate({
			submitHandler: function(form) {
				var respuesta = confirm('\xBFDesea realmente modificar a esta nueva persona?')
				if (respuesta)
					form.submit();
			}
		});
	});
	
	function fn_modificar(){
		var str = $("#frm_per").serialize();
		$.ajax({
			url: 'ajax_modificar.php',
			data: str,
			type: 'post',
			success: function(data){
				if(data != "")
					alert(data);
				fn_cerrar();
				fn_buscar();
			}
		});
	};
</script>