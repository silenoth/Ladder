<?
	include "../extras/php/conexion.php";
	include "../extras/php/basico.php";
	
	/*verificamos si las variables se envian*/
	if(empty($_POST['ide_pai']) || empty($_POST['usu_per']) || empty($_POST['nom_per']) || empty($_POST['ape_per']) || empty($_POST['email_per'])){
		echo "Usted no a llenado todos los campos";
		exit;
	}
	
	/*obtenemos el ide mayor*/
	$sql = "select ide_per from persona order by ide_per desc limit 1";
	$per = mysql_query($sql);
	$rs_per = mysql_fetch_assoc($per);
	
	/*insertamos el nuevo registro*/
	$ide_per = $rs_per['ide_per'] + 1;

	$sql = sprintf("INSERT INTO `persona` VALUES (%d, %d, '%s', '%s', '%s', '%s', now());",
		fn_filtro((int)$ide_per),
		fn_filtro((int)$_POST['ide_pai']),
		fn_filtro(substr($_POST['usu_per'], 0, 16)),
		fn_filtro(substr($_POST['nom_per'], 0, 60)),
		fn_filtro(substr($_POST['ape_per'], 0, 60)),
		fn_filtro(substr($_POST['email_per'], 0, 70))
	);

	if(!mysql_query($sql))
		echo "Error al insertar a la nueva persona:\n$sql";

	exit;
?>