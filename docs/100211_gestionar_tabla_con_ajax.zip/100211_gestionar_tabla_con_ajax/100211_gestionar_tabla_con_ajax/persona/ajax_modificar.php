<?
	include "../extras/php/conexion.php";
	include "../extras/php/basico.php";
	
	/*verificamos si las variables se envian*/
	if(empty($_POST['ide_per']) || empty($_POST['ide_pai']) || empty($_POST['nom_per']) || empty($_POST['ape_per']) || empty($_POST['email_per'])){
		echo "Usted no a llenado todos los campos";
		exit;
	}
	
	/*modificar el registro*/

	$sql = sprintf("UPDATE persona SET  ide_pai=%d, nom_per='%s', ape_per='%s', email_per='%s' where ide_per=%d;",
		fn_filtro((int)$_POST['ide_pai']),
		fn_filtro(substr($_POST['nom_per'], 0, 60)),
		fn_filtro(substr($_POST['ape_per'], 0, 60)),
		fn_filtro(substr($_POST['email_per'], 0, 70)),
		fn_filtro((int)$_POST['ide_per'])
	);
	if(!mysql_query($sql))
		echo "Error al insertar a la nueva persona:\n$sql";
	exit;
?>