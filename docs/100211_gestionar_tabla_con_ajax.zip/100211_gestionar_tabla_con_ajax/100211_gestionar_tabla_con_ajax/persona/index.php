<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Documento sin título</title>
        <script language="javascript" type="text/javascript" src="../extras/js/jquery-1.3.2.min.js"></script>
        <script language="javascript" type="text/javascript" src="../extras/js/jquery.blockUI.js"></script>
        <script language="javascript" type="text/javascript" src="../extras/js/jquery.validate.1.5.2.js"></script>
        <link href="../extras/css/estilo.css" rel="stylesheet" type="text/css" />
        <link href="../extras/php/PHPPaging.lib.css" rel="stylesheet" type="text/css" />
        <script language="javascript" type="text/javascript" src="index.js"></script>
    </head>
    <body>
    	<div id="cuerpo">
            <h1>jQuery - agregar y eliminar filas en una tabla v2</h1>
            <p>Esta nueva aplicación trabaja en una sola página, usando ajax, por medio de divs flotantes para la gestión, los plugins que uso son jquery.validate, jquery.blockUI</p>
            <form action="javascript: fn_buscar();" id="frm_buscar" name="frm_buscar">
                <table class="formulario">
                    <tbody>
                        <tr>
                            <td>Usu<strong>a</strong>rio</td>
                            <td><input name="criterio_usu_per" type="text" id="criterio_usu_per" /></td>
                            <td>Ordenar </td>
                            <td>
                            	<select name="criterio_ordenar_por" id="criterio_ordenar_por">
                                    <option value="ide_per">Ide</option>
                                	<option value="usu_per">Usuario</option>
                                    <option value="ape_per">Apellido</option>
                                    <option value="email_per">E-mail</option>
                                </select>
                            </td>
                            <td> En</td>
                            <td>
                            	<select name="criterio_orden" id="criterio_orden">
                                	<option value="desc">Descendente</option>
                                    <option value="asc">Ascendente</option>
                                </select>
                            </td>
                            <td>Registros</td>
                            <td>
                            	<select name="criterio_mostrar" id="criterio_mostrar">
                                	<option value="1">1</option>
                                	<option value="2">2</option>
                                	<option value="5">5</option>
                                	<option value="10">10</option>
                                	<option value="20" selected="selected">20</option>
                                	<option value="40">40</option>
                                </select>
                            </td>
                            <td><input type="submit" value="Buscar" /></td>
                        </tr>
                    </tbody>
                </table>
            </form>
            <div id="div_listar"></div>
            <div id="div_oculto" style="display: none;"></div>
            <p>Gracias a las siguientes personas</p>
            <ul>
            	<li><a href="mailto: william_jmm@hotmail.com">3w</a>, por hacer de tester en algunos momentos.</li>
            </ul>
            <p align="right">Cualquier duda a <strong>hector2c@live.com</strong><br /><a href="hector2c.wordpress.com" target="_blank">hector2c.wordpress.com</a></p>
        </div>
    </body>
</html>