<?
	include "../extras/php/conexion.php";
?>
<h1>Agregando nuevo usuario</h1>
<p>Por favor rellene el siguiente formulario</p>
<form action="javascript: fn_agregar();" method="post" id="frm_per">
    <table class="formulario">
        <tbody>
            <tr>
                <td>Usuario</td>
                <td><input name="usu_per" type="text" id="usu_per" size="16" class="required" /></td>
            </tr>
            <tr>
                <td>Nombre</td>
                <td><input name="nom_per" type="text" id="nom_per" size="40" class="required" /></td>
            </tr>
            <tr>
                <td>Apellido</td>
                <td><input name="ape_per" type="text" id="ape_per" size="40" class="required" /></td>
            </tr>
            <tr>
                <td>Pa&iacute;s</td>
                <td>
                	<select name="ide_pai" ide="ide_pai" class="required">
                    	<option value=""></option>
						<?
                            $sql = "select * from pais order by nom_pai asc";
                            $pai = mysql_query($sql);
                            while($rs_pai = mysql_fetch_assoc($pai)){
                        ?>
                            <option value="<?=$rs_pai['ide_pai']?>"><?=$rs_pai['nom_pai']?></option>
                        <? } ?>
					</select>
                </td>
            </tr>
            <tr>
                <td>E-mail</td>
                <td><input name="email_per" type="text" id="email_per" size="30" class="required email" /></td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="2">
                    <input name="agregar" type="submit" id="agregar" value="Agregar" />
                    <input name="cancelar" type="button" id="cancelar" value="Cancelar" onclick="fn_cerrar();" />
                </td>
            </tr>
        </tfoot>
    </table>
</form>
<script language="javascript" type="text/javascript">
	$(document).ready(function(){
		$("#frm_per").validate({
			rules:{
				usu_per:{
					required: true,
					remote: "ajax_verificar_usu_per.php"
				}
			},
			messages: {
				usu_per: "x"
			},
			onkeyup: false,
			submitHandler: function(form) {
				var respuesta = confirm('\xBFDesea realmente agregar a esta nueva persona?')
				if (respuesta)
					form.submit();
			}
		});
	});
	
	function fn_agregar(){
		var str = $("#frm_per").serialize();
		$.ajax({
			url: 'ajax_agregar.php',
			data: str,
			type: 'post',
			success: function(data){
				if(data != "")
					alert(data);
				fn_cerrar();
				fn_buscar();
			}
		});
	};
</script>